<?php
require_once 'config.php';

$mensaje_login_registro = "";

// -----------------------------------------------------------
// A. Lógica de Manejo de Formularios (POST)
// -----------------------------------------------------------
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // 1. Lógica de LOGIN (identificado por el campo 'login_attempt')
    if (isset($_POST['login_attempt'])) {
        $correo = trim($_POST["correo"]);
        $contrasena = trim($_POST["contrasena"]);
        
        $sql = "SELECT id_usuario, nombre, contraseña FROM usuario WHERE correo = ?";
        if($stmt = mysqli_prepare($link, $sql)){
            mysqli_stmt_bind_param($stmt, "s", $param_correo);
            $param_correo = $correo;
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                if(mysqli_stmt_num_rows($stmt) == 1){
                    mysqli_stmt_bind_result($stmt, $id, $nombre, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if($contrasena === $hashed_password){
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id_usuario"] = $id;
                            $_SESSION["nombre"] = $nombre;
                            header("location: index.php");
                            exit; 
                        } else{
                            $mensaje_login_registro = "Contraseña no válida.";
                        }
                    }
                } else{
                    $mensaje_login_registro = "Correo no registrado.";
                }
            }
            mysqli_stmt_close($stmt);
        }
    } 
    
    // 2. Lógica de REGISTRO (identificado por el campo 'register_attempt')
    elseif (isset($_POST['register_attempt'])) {
        $nombre = trim($_POST["nombre"]);
        $correo = trim($_POST["correo"]);
        $contrasena = trim($_POST["contrasena"]);
        $carrera = trim($_POST["carrera"]);
        
        $sql_insert = "INSERT INTO usuario (nombre, correo, contraseña, carrera) VALUES (?, ?, ?, ?)";
        if($stmt_insert = mysqli_prepare($link, $sql_insert)){
            mysqli_stmt_bind_param($stmt_insert, "ssss", $param_nombre, $param_correo, $param_contrasena, $param_carrera);
            $param_nombre = $nombre;
            $param_correo = $correo;
            $param_contrasena = $contrasena;
            $param_carrera = $carrera;
            
            if(mysqli_stmt_execute($stmt_insert)){
                $mensaje_login_registro = "¡Registro exitoso! Ya puedes iniciar sesión.";
            } else{
                $mensaje_login_registro = "Error: No se pudo registrar el usuario. El correo podría estar en uso.";
            }
            mysqli_stmt_close($stmt_insert);
        }
    }

    // 3. Lógica de PUBLICACIÓN de Comentario (solo si está logueado)
    elseif (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true && isset($_POST['texto_comentario'])) {
        $texto = trim($_POST['texto_comentario']);
        $calificacion = $_POST['calificacion'];
        $id_usuario = $_SESSION["id_usuario"];
        
        if (!empty($texto)) {
            $sql = "INSERT INTO comentario (id_usuario, texto_comentario, calificacion) VALUES (?, ?, ?)";
            if($stmt = mysqli_prepare($link, $sql)){
                mysqli_stmt_bind_param($stmt, "isd", $param_id, $param_texto, $param_calif);
                
                $param_id = $id_usuario;
                $param_texto = $texto;
                $param_calif = $calificacion;
                
                if(mysqli_stmt_execute($stmt)){
                    header("location: index.php");
                    exit;
                }
                mysqli_stmt_close($stmt);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Comentarios del restaurante</title>
    <style>
        /* CSS Básico para posición y tamaño */
        .nav-bar { padding: 10px; overflow: hidden; width: 100%; }
        .nav-bar a, .nav-bar span, .nav-bar button { text-decoration: none; padding: 10px 15px; float: right; cursor: pointer; border: 1px solid black; }
        .comment-box { padding: 10px; margin-bottom: 10px; width: 80%; }
        .form-container { padding: 15px; margin-bottom: 20px; width: 80%; }
        .modal { display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; }
        .modal-content { margin: 10% auto; padding: 20px; width: 30%; }
        .close { float: right; font-size: 28px; font-weight: bold; }
        input[type="text"], input[type="password"], input[type="email"], textarea, input[type="number"] { width: 100%; padding: 8px; margin: 5px 0; box-sizing: border-box; }
        button[type="submit"] { padding: 10px 15px; border: 1px solid black; cursor: pointer; width: 100%; margin-top: 10px; }
    </style>
</head>
<body>

    <div class="nav-bar">
        <span style="float: left;">Restaurante italiano</span>
        <?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true): ?>
            <button onclick="window.location.href='logout.php'" style="float: right;">Cerrar Sesión</button>
            <span style="float: right; padding: 10px 15px;">Hola, <?php echo htmlspecialchars($_SESSION["nombre"]); ?></span>
        <?php else: ?>
            <button onclick="document.getElementById('modalLogin').style.display='block'" style="float: right;">Iniciar Sesión</button>
            <button onclick="document.getElementById('modalRegistro').style.display='block'" style="float: right;">Registrarse</button>
        <?php endif; ?>
    </div>

    <h1>Opiniones de nuestros clientes</h1>
    
    <?php if (!empty($mensaje_login_registro)): ?>
        <p style='text-align: center; font-weight: bold;'><?php echo $mensaje_login_registro; ?></p>
    <?php endif; ?>

    <?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true): ?>
        <div class="form-container">
            <h3>¡Déjanos tu opinión!</h3>
            <form action="index.php" method="post">
                <textarea name="texto_comentario" rows="4" required placeholder="Escribe tu comentario aquí..." maxlength="500"></textarea><br>
                <label for="calificacion">Calificación:</label>
                <input type="number" name="calificacion" min="1" max="5" step="0.5" required style="width: 100px;"><br>
                <button type="submit">Publicar comentario</button>
            </form>
        </div>
    <?php else: ?>
        <div class="form-container" style="text-align: center;">
            <p><strong>Debes <a href="#" onclick="document.getElementById('modalLogin').style.display='block'">iniciar sesión</a> para poder publicar un comentario.</strong></p>
        </div>
    <?php endif; ?>

    <h2>Últimos comentarios</h2>
    <?php
    $sql = "SELECT c.texto_comentario, c.calificacion, DATE_FORMAT(c.fecha_de_publicacion, '%d-%m-%Y %H:%i') AS fecha, u.nombre 
            FROM comentario c 
            JOIN usuario u ON c.id_usuario = u.id_usuario 
            ORDER BY c.fecha_de_publicacion DESC";

    if($result = mysqli_query($link, $sql)){
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_array($result)){
                echo "<div class='comment-box'>";
                    echo "<div>";
                        echo htmlspecialchars($row['nombre']) . " - Puntuación: " . htmlspecialchars($row['calificacion']) . " / 5";
                    echo "</div>";
                    echo "<p>" . htmlspecialchars($row['texto_comentario']) . "</p>";
                    echo "<small>Publicado el: " . htmlspecialchars($row['fecha']) . "</small>";
                echo "</div>";
            }
            mysqli_free_result($result);
        } else{
            echo "<p>Aún no hay comentarios. ¡Sé el primero en opinar!</p>";
        }
    } else{
        echo "ERROR: No se pudo cargar los comentarios.";
    }
    // No cerrar la conexión aquí si vas a usar logout.php, pero por buenas prácticas lo cerramos si el script terminó
    // mysqli_close($link); 
    ?>

    <div id="modalLogin" class="modal">
        <div class="modal-content">
            <span class="close" onclick="document.getElementById('modalLogin').style.display='none'">&times;</span>
            <h2>Iniciar sesión</h2>
            <form action="index.php" method="post">
                <input type="hidden" name="login_attempt" value="1">
                <label for="login_correo">Correo:</label>
                <input type="email" id="login_correo" name="correo" required>
                <label for="login_contraseña">Contraseña:</label>
                <input type="password" id="login_contraseña" name="contrasena" required>
                <button type="submit">Entrar</button>
            </form>
        </div>
    </div>

    <div id="modalRegistro" class="modal">
        <div class="modal-content">
            <span class="close" onclick="document.getElementById('modalRegistro').style.display='none'">&times;</span>
            <h2>Registrarse</h2>
            <form action="index.php" method="post">
                <input type="hidden" name="register_attempt" value="1">
                <label for="reg_nombre">Nombre:</label>
                <input type="text" id="reg_nombre" name="nombre" required>
                <label for="reg_correo">Correo:</label>
                <input type="email" id="reg_correo" name="correo" required>
                <label for="reg_contraseña">Contraseña:</label>
                <input type="password" id="reg_contraseña" name="contrasena" required>
                <label for="reg_carrera">Carrera (Opcional):</label>
                <input type="text" id="reg_carrera" name="carrera">
                <button type="submit">Registrarme</button>
            </form>
        </div>
    </div>

    <script>
        // Cerrar modales si se hace click fuera
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = "none";
            }
        }
    </script>
</body>
</html>